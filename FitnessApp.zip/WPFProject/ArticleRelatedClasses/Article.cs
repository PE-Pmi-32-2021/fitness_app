﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFProject
{
    class Article
    {
        public string Path { get; set; }
        public string PhotoURI { get; set; }
        public string Heading { get; set; }
    }
}
