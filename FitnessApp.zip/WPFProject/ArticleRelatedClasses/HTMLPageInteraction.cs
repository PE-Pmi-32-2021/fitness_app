﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HtmlAgilityPack;

namespace WPFProject
{
    static class HTMLPageScraper
    {
        public static IEnumerable<Article> GetDescendantArticles(string HTMLPath, string XPath)
        {
            HtmlWeb web = new HtmlWeb();
            HtmlDocument doc = web.Load(HTMLPath);

            HtmlNodeCollection articleNames = doc.DocumentNode.SelectNodes(XPath);

            foreach (HtmlNode node in articleNames)
            {
                Article article = new Article();

                article.Path = "https://in.iherb.com" + node.ChildNodes["a"].Attributes["href"].Value;
                article.Heading = node.ChildNodes["a"].Attributes["aria-label"].Value[0..^5];
                article.PhotoURI = node.ChildNodes["div"].ChildNodes["img"].Attributes["src"].Value;
                Console.WriteLine(article.PhotoURI);

                yield return article;
            }
        }
    }
}
