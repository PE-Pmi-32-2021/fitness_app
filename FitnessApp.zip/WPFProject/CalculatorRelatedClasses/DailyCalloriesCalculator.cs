﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFProject
{
    public static class DailyCalloriesCalculator
    {
        public static Dictionary<string, double> ActivityLevelCoefs = new Dictionary<string, double>
           {
               ["Sedentary"] = 1.2,
               ["Lightly Active"] = 1.375,
               ["Moderately Active"] = 1.55,
               ["Very Active"] = 1.725,
               ["Extra Active"] = 1.9

           };
        public static int DailyCallories(string sex, double weightInKilos, int heightInCM, int ageInYears, string activityLevel)
        {
            
            //Female BMR = 655 + (9.6 X weight in kilos) + (1.8 X height in cm) – (4.7 x age in years).
            if (sex == "female")
            {
                double BMR = 655 + (9.6 * weightInKilos) + (1.8 * heightInCM) - (4.7 * ageInYears);
                return Convert.ToInt32(ActivityLevelCoefs[activityLevel] * BMR);
            }
            //Males BMR = 66 + (13.7 x weight in kilos) + (5 x height in cm) – (6.8 x age in years)
            else
            {
                double BMR = 66 + (13.7 * weightInKilos) + (5 * heightInCM) - (6.8 * ageInYears);
                return Convert.ToInt32(ActivityLevelCoefs[activityLevel] * BMR);
            }
        }
    }
}
