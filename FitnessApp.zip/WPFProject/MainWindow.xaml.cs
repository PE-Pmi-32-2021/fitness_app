﻿using System;
using System.Threading.Tasks;
using System.Windows;

namespace WPFProject
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private User CurrentUser { get; set; }
        private MyAccountWindow MyAccount { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            UserToDB.DBConfig = "Host=localhost;Username=postgres;Password=1854;Database=fitness_app_db";
            this.UserLogin.Focus();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            if (this.UserLogin.Text != "" && this.UserPassword.Text != "")
            {
                User user = UserToDB.GetUserFromDB(this.UserLogin.Text);
                if (user != null)
                {
                    if (user.Password == UserPassword.Text)
                    {
                        this.CurrentUser = user;

                        MyAccount = new MyAccountWindow(user);
                        this.Hide();
                        MyAccount.Show();
                    }
                    else
                        MessageBox.Show("Incorrect Password");
                }
                else
                {
                    MessageBox.Show("User doesn't exist");
                }
            }
            else
            {
                MessageBox.Show("Enter login and password");
            }
        }
    }
}
