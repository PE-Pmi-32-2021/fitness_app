﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;

namespace WPFProject
{
    public static class ProductToDB
    {
        public static string DBConfig { get; set; }
        public static IEnumerable<Product> GetProducts()
        {
            NpgsqlConnection connection = new NpgsqlConnection(ProductToDB.DBConfig);
            connection.Open();

            string sqlQuery = "select * from products";


            NpgsqlCommand command = new NpgsqlCommand(sqlQuery, connection);


            NpgsqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                Product product = new Product();

                product.Name = reader.GetFieldValue<string>(0);
                product.CaloriesAmount = reader.GetFieldValue<int>(1);
                product.PircturePath = reader.GetFieldValue<string>(2);

                yield return product;
            }

            connection.Close();
        }
    }
}
