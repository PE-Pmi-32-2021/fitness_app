﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPFProject
{
    public class User
    {
        public string Login { get; set; }
        public string Password { get; set; }
        public int Height { get; set; }
        public int Weight { get; set; }
        public int Age { get; set; }
        public string Sex { get; set; }

        public override string ToString()
        {
            return $"'{Login}', '{Password}', {Height}, {Weight}, {Age}, '{Sex}'";
        }
    }
}
