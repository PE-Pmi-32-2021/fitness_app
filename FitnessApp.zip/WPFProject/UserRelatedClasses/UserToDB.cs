﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;

namespace WPFProject
{
    public static class UserToDB
    {
        public static string DBConfig { get; set; }
        public static User GetUserFromDB (string login)
        {
            User user = new User();

            NpgsqlConnection connection = new NpgsqlConnection(UserToDB.DBConfig);
            connection.Open();

            string sqlQuery = "select * from users " +
                                $"where login = '{login}'";


            NpgsqlCommand command = new NpgsqlCommand(sqlQuery, connection);

            NpgsqlDataReader reader = command.ExecuteReader();

            bool userExists = reader.Read();

            if (userExists)
            {
                user.Login = reader.GetValue(0).ToString();
                user.Password = reader.GetValue(1).ToString();
                user.Height = reader.GetInt32(2);
                user.Weight = reader.GetInt32(3);
                user.Age = reader.GetInt32(4);
                user.Sex = reader.GetValue(5).ToString();
            }
            else
            {
                user = null;
            }
            connection.Close();

            return user;
        }

        public static void UpdateUserDB (User user)
        {
            NpgsqlConnection connection = new NpgsqlConnection(UserToDB.DBConfig);
            connection.Open();

            string sqlQuery = "update users " +
                                $"set height = {user.Height}, " +
                                $"weight = {user.Weight}, " +
                                $"age = {user.Age}, " +
                                $"sex = '{user.Sex}' " +
                                $"where login = '{user.Login}' and " +
                                $"password = '{user.Password}' "; 


            NpgsqlCommand command = new NpgsqlCommand(sqlQuery, connection);

            command.ExecuteNonQuery();

            connection.Close();
        }

        public static void AddUserToDB (User user)
        {
            NpgsqlConnection connection = new NpgsqlConnection(UserToDB.DBConfig);
            connection.Open();

            string sqlQuery = "insert into users values\n" +
                                $"({user})";


            NpgsqlCommand command = new NpgsqlCommand(sqlQuery, connection);

            command.ExecuteNonQuery();

            connection.Close();
        }
    }
}
