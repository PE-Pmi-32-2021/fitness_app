﻿using System;
using System.Diagnostics;
using System.Windows.Navigation;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace WPFProject
{
    /// <summary>
    /// Interaction logic for ArticlesWindow.xaml
    /// </summary>
    public partial class ArticlesWindow : Window
    {

        private IEnumerable<Article> ArticlesEnumerable;

        public MyAccountWindow Account;
        public ProductsWindow Products;
        public CalculatorWindow Calculator;
        public ArticlesWindow()
        {
            InitializeComponent();

            ArticlesEnumerable = HTMLPageScraper.GetDescendantArticles("https://in.iherb.com/blog/nutrition", "//article[@class='article-preview']");

            foreach (Article article in ArticlesEnumerable)
            {
                Border border = new Border();
                border.Width = 300;
                border.Height = 250;
                border.Padding = new Thickness(10);

                StackPanel panel = new StackPanel();

                Image image = new Image();
                BitmapImage bitmap = new BitmapImage();
                bitmap.BeginInit();
                bitmap.UriSource = new Uri(article.PhotoURI, UriKind.Absolute);
                bitmap.EndInit();
                image.Source = bitmap;
                image.Width = border.Width;
                image.Height = 150;
                image.MouseUp += Image_MouseUp;

                TextBlock name = new TextBlock();
                name.Text = article.Heading;
                name.TextWrapping = TextWrapping.WrapWithOverflow;
                name.Foreground = Brushes.White;
                name.TextAlignment = TextAlignment.Center;

                panel.Children.Add(image);
                panel.Children.Add(name);

                border.Child = panel;


                this.ArticlesPanel.Children.Add(border);
            }
        }
        private void ContextMenuIcon_MouseEnter(object sender, MouseEventArgs e)
        {
            this.ContextMenuIcon.Foreground = (SolidColorBrush)new BrushConverter().ConvertFrom("#FF0BDA51"); ;
        }

        private void ContextMenuIcon_MouseLeave(object sender, MouseEventArgs e)
        {
            this.ContextMenuIcon.Foreground = Brushes.White;
        }

        private void ContextMenuIcon_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (this.MainGrid.ColumnDefinitions[0].Width == new GridLength(0))
            {
                this.MainGrid.ColumnDefinitions[0].Width = new GridLength(160);
            }

            else
            {
                this.MainGrid.ColumnDefinitions[0].Width = new GridLength(0);
            }
        }

        private void Image_MouseUp (object sender, MouseEventArgs e)
        {
            Image image = (Image)e.Source;
            TextBlock textBlock = (TextBlock)(((StackPanel)(image.Parent)).Children[1]);

            foreach (Article article in ArticlesEnumerable)
            {
                if (textBlock.Text == article.Heading)
                {
                    Process process = new Process();
                    process.StartInfo.UseShellExecute = true;
                    process.StartInfo.FileName = article.Path;
                    process.Start();
                    e.Handled = true;
                    break;
                }
            }
        }


        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (SearchBox.Text == "")
            {
                foreach (Border border in this.ArticlesPanel.Children)
                {
                    border.Visibility = Visibility.Visible;
                }
            }

            else
            {
                foreach (Border border in this.ArticlesPanel.Children)
                {
                    if (((TextBlock)((StackPanel)border.Child).Children[1]).Text.ToLower().Contains(SearchBox.Text.Trim().ToLower()))
                    {
                        border.Visibility = Visibility.Visible;
                    }
                    else
                    {
                        border.Visibility = Visibility.Collapsed;
                    }
                }
            }

        }




        private void GoToCalculatorButton_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            this.Calculator.Show();
        }

        private void GoToProducts_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            this.Products.Show();
        }

        private void GoToMyAccount_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            this.Account.Show();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}
