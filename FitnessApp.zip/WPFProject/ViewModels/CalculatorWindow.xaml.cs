﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPFProject
{
    /// <summary>
    /// Interaction logic for Calculator.xaml
    /// </summary>
    public partial class CalculatorWindow : Window
    {
        private User CurrentUser;
        public MyAccountWindow Account { get; set; }
        public ArticlesWindow Articles { get; set; }
        public ProductsWindow Products { get; set; }
        public CalculatorWindow(User user)
        {
            InitializeComponent();

            this.CurrentUser = user;

            this.SexCB.Text = this.CurrentUser.Sex;
            this.HeightTB.Text = this.CurrentUser.Height.ToString();
            this.WeightTB.Text = this.CurrentUser.Weight.ToString();
            this.AgeTB.Text = this.CurrentUser.Age.ToString();
        }

        private void CalcBTN_Click(object sender, RoutedEventArgs e)
        {
            int result = DailyCalloriesCalculator.DailyCallories(SexCB.Text, Convert.ToDouble(WeightTB.Text), Convert.ToInt32(HeightTB.Text), Convert.ToInt32(AgeTB.Text), ActivityLevelCB.Text);

            ResultLBL.Content = result.ToString() + "kk";
        }


        private void ContextMenuIcon_MouseEnter(object sender, MouseEventArgs e)
        {
            this.ContextMenuIcon.Foreground = (SolidColorBrush)new BrushConverter().ConvertFrom("#FF0BDA51"); ;
        }

        private void ContextMenuIcon_MouseLeave(object sender, MouseEventArgs e)
        {
            this.ContextMenuIcon.Foreground = Brushes.White;
        }

        private void ContextMenuIcon_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (this.MainGrid.ColumnDefinitions[0].Width == new GridLength(0))
            {
                this.MainGrid.ColumnDefinitions[0].Width = new GridLength(160);
            }

            else
            {
                this.MainGrid.ColumnDefinitions[0].Width = new GridLength(0);
            }
        }


        private void GoToProducts_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            this.Products.Show();
        }

        private void GoToArticles_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            this.Articles.Show();
        }

        private void GoToMyAccount_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            this.Account.Show();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void Window_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            this.SexCB.Text = this.CurrentUser.Sex;
            this.HeightTB.Text = this.CurrentUser.Height.ToString();
            this.WeightTB.Text = this.CurrentUser.Weight.ToString();
            this.AgeTB.Text = this.CurrentUser.Age.ToString();
        }
    }
}
