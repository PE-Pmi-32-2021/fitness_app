﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPFProject
{
    /// <summary>
    /// Interaction logic for MyAccount.xaml
    /// </summary>
    public partial class MyAccountWindow : Window
    {
        private User CurrentUser;
        private CalculatorWindow Calculator { get; set; }
        private ArticlesWindow Articles { get; set; }
        private ProductsWindow Products { get; set; }

        public MyAccountWindow(User user)
        {
            InitializeComponent();

            this.CurrentUser = user;

            this.Calculator = new CalculatorWindow(user);
            this.Articles = new ArticlesWindow();
            this.Products = new ProductsWindow();

            this.Calculator.Account = this;
            this.Calculator.Articles = this.Articles;
            this.Calculator.Products = this.Products;

            this.Articles.Account = this;
            this.Articles.Calculator = this.Calculator;
            this.Articles.Products = this.Products;

            this.Products.Account = this;
            this.Products.Calculator = this.Calculator;
            this.Products.Articles = this.Articles;




            this.SexCB.Text = this.CurrentUser.Sex;
            this.UserHeight.Text = this.CurrentUser.Height.ToString();
            this.UserWeight.Text = this.CurrentUser.Weight.ToString();
            this.UserAge.Text = this.CurrentUser.Age.ToString();

            AccountImage.Source = new BitmapImage
            (
            new Uri
                (
                    System.IO.Path.Combine(Directory.GetParent(Environment.CurrentDirectory).Parent.Parent.FullName, "profileImages", $"{this.CurrentUser.Sex}.png"),
                    UriKind.Absolute
                )
            );

        }
        private void SexCB_DropDownClosed(object sender, EventArgs e)
        {
            string photoPath = System.IO.Path.Combine(Directory.GetParent(Environment.CurrentDirectory).Parent.Parent.FullName, "profileImages", $"{this.SexCB.Text}.png");
            AccountImage.Source = new BitmapImage(new Uri(photoPath, UriKind.Absolute));
        }

        private void ContextMenuIcon_MouseEnter(object sender, MouseEventArgs e)
        {
            this.ContextMenuIcon.Foreground = (SolidColorBrush)new BrushConverter().ConvertFrom("#FF0BDA51"); ;
        }

        private void ContextMenuIcon_MouseLeave(object sender, MouseEventArgs e)
        {
            this.ContextMenuIcon.Foreground = Brushes.White;
        }

        private void ContextMenuIcon_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (this.MainGrid.ColumnDefinitions[0].Width == new GridLength(0))
            {
                this.MainGrid.ColumnDefinitions[0].Width = new GridLength(160);
            }

            else
            {
                this.MainGrid.ColumnDefinitions[0].Width = new GridLength(0);
            }
        }

        private async void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            this.CurrentUser.Sex = this.SexCB.Text;
            this.CurrentUser.Height = int.Parse(this.UserHeight.Text);
            this.CurrentUser.Weight = int.Parse(this.UserWeight.Text);
            this.CurrentUser.Age = int.Parse(this.UserAge.Text);

            await Task.Run(() => UserToDB.UpdateUserDB (this.CurrentUser));

            MessageBox.Show("Modifications applied");
        }

        private void GoToCalculatorButton_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            Calculator.Show();
        }

        private void GoToProducts_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            Products.Show();
        }

        private void GoToArticles_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            Articles.Show();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            Application.Current.Shutdown();
        }


    }
}
