﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WPFProject
{
    /// <summary>
    /// Interaction logic for Products.xaml
    /// </summary>
    public partial class ProductsWindow : Window
    {
        public MyAccountWindow Account { get; set; }
        public ArticlesWindow Articles { get; set; }
        public CalculatorWindow Calculator { get; set; }
        public ProductsWindow()
        {
            InitializeComponent();

            ProductToDB.DBConfig = "Host=localhost;Username=postgres;Password=1854;Database=fitness_app_db";

            foreach (Product product in ProductToDB.GetProducts())
            {
                Border border = new Border();
                border.Padding = new Thickness(10);

                StackPanel panel = new StackPanel();

                Image image = new Image();
                BitmapImage bitmap = new BitmapImage();
                bitmap.BeginInit();
                bitmap.UriSource = new Uri(product.PircturePath, UriKind.Absolute);
                bitmap.EndInit();
                image.Source = bitmap;
                image.Width = 150;
                image.Height = 150;


                TextBlock name = new TextBlock();
                name.Text = $"Name: {product.Name}";
                name.Foreground = Brushes.White;

                TextBlock calories = new TextBlock();
                calories.Text = $"Calories: {product.CaloriesAmount} per 100g";
                calories.Foreground = Brushes.White;

                name.TextAlignment = TextAlignment.Center;
                calories.TextAlignment = TextAlignment.Center;
                
                panel.Children.Add(image);
                panel.Children.Add(name);
                panel.Children.Add(calories);

                border.Child = panel;

                this.ProductsPanel.Children.Add(border);
            }
        }

        private void ContextMenuIcon_MouseEnter(object sender, MouseEventArgs e)
        {
            this.ContextMenuIcon.Foreground = (SolidColorBrush)new BrushConverter().ConvertFrom("#FF0BDA51"); ;
        }

        private void ContextMenuIcon_MouseLeave(object sender, MouseEventArgs e)
        {
            this.ContextMenuIcon.Foreground = Brushes.White;
        }

        private void ContextMenuIcon_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (this.MainGrid.ColumnDefinitions[0].Width == new GridLength(0))
            {
                this.MainGrid.ColumnDefinitions[0].Width = new GridLength(160);
            }

            else
            {
                this.MainGrid.ColumnDefinitions[0].Width = new GridLength(0);
            }
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (SearchBox.Text == "")
            {
                foreach (Border border in this.ProductsPanel.Children)
                {
                    border.Visibility = Visibility.Visible;
                }
            }

            else
            {
                foreach (Border border in this.ProductsPanel.Children)
                {
                    if (((TextBlock)((StackPanel)border.Child).Children[1]).Text.Split (": ")[1].ToLower().Contains (SearchBox.Text.Trim ().ToLower()))
                    {
                        border.Visibility = Visibility.Visible;
                    }
                    else
                    {
                        border.Visibility = Visibility.Collapsed;
                    }
                }
            }
            
        }

        private void GoToMyAccount_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            this.Account.Show();
        }

        private void GoToCalculatorButton_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            this.Calculator.Show();
        }

        private void GoToArticles_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            this.Articles.Show();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            Application.Current.Shutdown ();
        }
    }
}
